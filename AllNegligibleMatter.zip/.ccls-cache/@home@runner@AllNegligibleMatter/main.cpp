#include "class.h"

int main() {
    VendingMachine vg;

    Snack chips("Chips", 50, 5);
    Snack *bounty = new Snack("Bounty", 65, 3);  
    Snack *snickers = new Snack("Snickers", 55, 4);  

    vg.addItem(chips);
    vg.addItem(*bounty);  
    vg.addItem(*snickers);  

    vg.displayInfo();

    ItemIndex itemIndex = CHIPS;
    double amount = 100;
    vg.addBalance(amount);
    cout << "Баланс после добавления: " << vg.getBalance() << " руб." << endl;

    double change = amount - chips.getPrice();  
    cout << "Остаток сдачи: " << change << " руб." << endl;
    cout << itemIndex << endl;

    delete bounty;
    delete snickers;

    return 0;
}