#include "class.h"

string Snack::getProductName() {
    return product_name;
}

void Snack::setProductName(string name) {
    product_name = name;
}

double Snack::getPrice() {
    return price;
}

void Snack::setPrice(double p) {
    price = p;
}

int Snack::getQuantity() {
    return quantity;
}

void Snack::setQuantity(int q) {
    quantity = q;
}

Snack::Snack(string name, double cena, int kol) {
    product_name = name;
    price = cena;
    quantity = kol;
}

VendingMachine::VendingMachine() : balance(0), amount_of_cash(0) {}

void VendingMachine::addItem(Snack newItem) {
    items.push_back(newItem);
}

void VendingMachine::removeItem(int itemIndex) {
    if (itemIndex >= 0 && itemIndex < items.size()) {
        items.erase(items.begin() + itemIndex);
    }
}

void VendingMachine::addBalance(double amount) {
    balance += amount;
}

void VendingMachine::removeBalance(double amount) {
    balance -= amount;
}

void VendingMachine::displayInfo() {
    for (int i = 0; i < items.size(); i++) {
        cout << i << ". " << items[i].getProductName() << " - " << items[i].getPrice() << " руб., "
             << items[i].getQuantity() << " шт." << endl;
    }
}

double VendingMachine::getBalance() const {
    return balance;
}

double VendingMachine::getAmountOfCash() const {
    return amount_of_cash;
}