#ifndef VENDING_MACHINE_H
#define VENDING_MACHINE_H

#include <iostream>
#include <vector>

using namespace std;

class Snack {
private:
    string product_name;
    double price;
    int quantity;

public:
    string getProductName();
    void setProductName(string name);
    double getPrice();
    void setPrice(double p);
    int getQuantity();
    void setQuantity(int q);
    Snack(string name, double cena, int kol);
};

class VendingMachine {
private:
    vector<Snack> items;
    double balance;
    double amount_of_cash;

public:
    VendingMachine();
    void addItem(Snack newItem);
    void removeItem(int itemIndex);
    void addBalance(double amount);
    void removeBalance(double amount);
    void displayInfo();
    double getBalance() const;
    double getAmountOfCash() const;
};

enum ItemIndex {
    CHIPS,
    COFFEE,
    ENERGETIK
};

#endif // VENDING_MACHINE_H